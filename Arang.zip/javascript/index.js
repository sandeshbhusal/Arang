document.addEventListener("readystatechange", start, false);
function start(){
    
}
function redirect(href){
    
}