$("#SPT").change(function(){
    var selected = alert($("#SPT :selected").val());
});
function appendor(){
    
}