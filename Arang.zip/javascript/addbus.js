$("#check").click(function(){
    $("#defTab").slideUp();
    $("#vehicleTab").fadeIn();
});
$("#verifyVehicle").click(function(){
    location.assign("yatru.html");
});